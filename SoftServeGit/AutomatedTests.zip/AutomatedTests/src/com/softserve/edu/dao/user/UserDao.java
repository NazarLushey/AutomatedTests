package com.softserve.edu.dao.user;
import com.j256.ormlite.dao.Dao;

public interface UserDao extends Dao<User, Integer> {
	// empty wrapper, you can add additional DAO methods here
}
