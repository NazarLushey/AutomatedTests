package com.softserve.edu.dao.user;

import java.util.List;

public class UserProcessor {

	public UserProcessor() {
	}

	public List<User> selectAllFromTable() {

		return null;
	}

	public User selectFromTableById(String id) {
		return null;
	}
}
