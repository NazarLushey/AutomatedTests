package com.softserve.edu.dao.userroles;

import com.j256.ormlite.dao.Dao;

public interface UserRoleDao extends Dao<UserRole, Integer> {

}
