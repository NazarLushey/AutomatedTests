package com.softserve.edu.dao.orderstatus;

import com.j256.ormlite.dao.Dao;

public interface OrderStatusDao extends Dao<OrderStatus, Integer> {

}
