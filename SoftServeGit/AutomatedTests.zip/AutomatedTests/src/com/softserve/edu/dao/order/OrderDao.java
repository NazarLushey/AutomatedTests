package com.softserve.edu.dao.order;

import com.j256.ormlite.dao.Dao;

public interface OrderDao extends Dao<Order, Integer> {

}
