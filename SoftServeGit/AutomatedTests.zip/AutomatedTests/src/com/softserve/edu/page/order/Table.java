package com.softserve.edu.page.order;

public class Table {

}
